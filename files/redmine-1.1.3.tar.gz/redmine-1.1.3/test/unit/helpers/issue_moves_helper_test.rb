require 'test_helper'

class IssueMovesHelperTest < ActionView::TestCase
end
